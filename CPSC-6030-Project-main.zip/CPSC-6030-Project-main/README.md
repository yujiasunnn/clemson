# CPSC-6030-Project

Fall 2022 CPSC-6030 Data Visualization Project Team 1

Emma Coen, Tsu-Yao Chang, Yujia Sun

[Project Screen-cast](https://vimeo.com/780996275)
